#==============================================================================
#' Parse Formula
#'
#' Extracts components of \code{formula} by variable type.
#' @param   formula   a formula object of the form \code{y ~ x | g}.
#' @return  Returns a list of vectors containing \code{response},
#'   \code{covariate}, and \code{group} variables from \code{formula}.
#'
#' @author Nathan Lucas
#' @export
# @seealso \code{\link{[nlme]getResponseFormula}},
#          \code{\link{[nlme]getCovariateFormula}},
#          \code{\link{[nlme]getGroupsFormula}}
#' @examples
#' parse_formula(y ~ x | g)$response   # "y"
#' parse_formula( ~ x | g)$response    # character(0)
#------------------------------------------------------------------------------
parse_formula <- function(formula)
{
  if (!requireNamespace("nlme", quietly = TRUE))
  {
    stop("'nlme' package needed for this function to work.", call. = FALSE)
  }
  vars <- stats::terms(stats::as.formula(formula))
  y <- if (attr(vars, "response"))
  {
    nlme::getResponseFormula(formula)
  }
  x <- nlme::getCovariateFormula(formula)
  g <- nlme::getGroupsFormula(formula)
  list(response  = all.vars(y),
       covariate = all.vars(x),
       group     = all.vars(g))
}
#------------------------------------------------------------------------------
# To create documentation and update package:
# > library(devtools)
# > library(roxygen2)
# > document()
# > build()
# > install()
#------------------------------------------------------------------------------
# Changelog
# 2017-10-23  Created.
#==============================================================================
