#==============================================================================
#' Model fitting utilities for R
#'
#' Utility functions to make model fitting easier and more consistent.
#'
#' @docType package
#' @name modlr
NULL

# #' @import methods
# NULL

#------------------------------------------------------------------------------
# Instructions to create documentation and update this package.

# # Load the package and create an object representation (current.code)
# # of the entire package in the user's workspace
# current.code <- devtools::as.package()

# # Load all R files from the package into the user's workspace as
# # if the the package was already installed -- load_all() roughly
# # simulates installation and loading with library()
# devtools::load_all()

# Create the required documentation files for each function and the
# package, and updates the NAMESPACE and DESCRIPTION files -- document()
# is a wrapper for the roxygenize() function from the roxygen2 package
# devtools::document()

#------------------------------------------------------------------------------

# Changelog
# 2017-10-23  Created.
#==============================================================================
