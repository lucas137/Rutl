#==============================================================================
#' Plotting utilities for R
#'
#' Utility functions to make plotting easier and more consistent.
#'
#' @docType package
#' @name plotr
NULL

# #' @import methods
# NULL

#------------------------------------------------------------------------------
# Changelog
# 2017-10-25  Created.
#==============================================================================
