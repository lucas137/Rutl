#==============================================================================

#------------------------------------------------------------------------------
#' Save Plot to PNG
#'
#' Saves a plot as a PNG file and optionally prints the plot.
#'
#' @param   x     a plot to save.
#' @param   file  name of output file without extension, up to 507 characters.
#' @param   prt   \code{TRUE} to also print plot.
#' @param   ...   more parameters passed to \code{png()}.
#' @return  Returns the file name of the output PNG image.
#'
#' @author  Nathan Lucas
#' @export
#' @examples
#' dir.create("plotdir", showWarnings = FALSE, recursive = TRUE)
#' plot_png(plot(sin, -pi, pi), file = "plotdir/sine", width = 7, height = 7)
#------------------------------------------------------------------------------
plot_png <- function(x, file, prt = TRUE, ...)
{
  if (is.null(file) || (file == ""))
  {
    stop("ERROR: argument 'file' must contain a file path")
  }
  filename <- paste(file, ".png", sep = "")
  if (prt)
  {
    utils::capture.output(x)                                    # print plot
    grDevices::dev.copy(grDevices::png, filename = filename,    # copy to file
                        units = "in", res = 300,
                        type = "cairo", ...);
  }
  else
  {
    grDevices::png(filename = filename, units = "in",   # graphics device
                   res = 300, type = "cairo", ...)
    utils::capture.output(x)                            # copy plot to file
  }
  grDevices::dev.off()    # shut down the current device
  filename                # return file name
}

# #------------------------------------------------------------------------------
# #' Save Plots to PNG
# #'
# #' Saves multiple plots as PNG files and optionally prints the plots.
# #'
# #' @param   x     list of plots to save.
# #' @param   file  base name of the output file without extension.
# #' @param   prt   \code{TRUE} to also print plot.
# #' @param   ...   more parameters passed to \code{png()}.
# #' @return  Returns the PNG file name template.
# #'
# #' @author  Nathan Lucas
# #' @export
# #' @examples
# #' dir.create("plotdir", showWarnings = FALSE, recursive = TRUE)
# #' plotsin <- function() { plot(sin, -pi, pi) }
# #' plotcos <- function() { plot(cos, -pi, pi) }
# #' plot_pngs(list(plotsin, plotcos),
# #'           file = "plotdir/trig", width = 7, height = 7)
# #------------------------------------------------------------------------------
# plot_pngs <- function(x, file = NULL, prt = TRUE, ...)
# {
#   if (is.null(file) || (file == ""))
#   {
#     stop("ERROR: argument 'file' must contain a file path")
#   }
#   filename <- paste(file, "%02d.png", sep = "")
#   if (prt)
#   {
#     lapply(1:length(x), function(i) {
#       capture.output(x[[i]])                              # print plot
#       dev.copy(png, filename = filename, units = "in",    # copy to file
#                res = 300, type = "cairo", ...);
#       dev.off()     # shut down the current device
#     })
#   }
#   else
#   {
#     png(filename = filename, units = "in",      # graphics device
#         res = 300, type = "cairo", ...)
#     capture.output(
#       lapply(1:length(x), function(i) x[[i]])   # copy to files
#     )
#     dev.off()     # shut down the current device
#   }
#   filename      # return file name
# }

#------------------------------------------------------------------------------
# Changelog
# 2017-10-23  Created.
#==============================================================================
