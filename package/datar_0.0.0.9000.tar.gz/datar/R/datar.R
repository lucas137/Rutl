#==============================================================================
#' Data Utilities for R
#'
#' Utility functions to make data manipulation easier and more consistent.
#'
#' @author   Nathan Lucas
#' @docType  package
#' @name     datar
NULL

# #' @import methods
# NULL

#------------------------------------------------------------------------------
# Changelog
# 2017-10-25  Created.
#==============================================================================
